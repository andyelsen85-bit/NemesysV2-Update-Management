# NemesysV2 Update Management

Windows software update enforcement with a server control center, client sync protocol, and audit visibility.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (binds to `PORT`, 8080 in the preview workflow)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — PostgreSQL connection string, supplied by the target Kubernetes environment
- Runtime env: `PORT` — HTTP listen port; the Kubernetes Service/Ingress should route the admin console and API to this port
- Runtime env: `SESSION_SECRET` — session signing secret for administrator sessions
- Bootstrap env: `NEMESYS_ADMIN_USERNAME` and `NEMESYS_ADMIN_PASSWORD` — used only when the administrator credential has not yet been initialized

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/nemesys-console` — React admin console for overview, clients, software policies, audit history, administrators, LDAP/PKI security, API-key management, and server settings.
- `artifacts/api-server` — Express API used by the control center and Windows service.
- `clients/windows-service` — Windows-targeted LocalSystem service, DPAPI key storage, hostname enrollment, policy evaluation, and user-session countdown companion.
- `lib/api-spec/openapi.yaml` — source of truth for dashboard, policy, client, settings, audit, and sync contracts.
- `lib/db/src/schema/index.ts` — Drizzle schema for Nemesys clients, policies, audit records, server settings, LDAP configuration, administrator users, and encrypted SSL material.

## Architecture decisions

- The admin console and future Windows client use the same generated OpenAPI contract.
- The server is designed to run as a stateless Kubernetes workload with PostgreSQL provided by the existing cluster/database stack; do not introduce a Replit-specific database or deployment dependency.
- Client sync configuration is separate from the admin surface so the sync port can later be exposed through IIS/firewall policy independently.
- Clients authenticate with one shared API key, while the server stores a SHA-256 authentication hash plus an encrypted recovery copy. Client identity is the Windows hostname; individual client certificates are not part of the design.
- API-key rotation returns the plaintext key once for silent installation/reconfiguration commands. Windows clients must protect the key with DPAPI; the server hostname may remain plain text in the local client configuration.
- The effective sync contract includes per-application Update Mode and each policy's close-on-start timeout, so a running Windows client can apply policy changes without service restart.
- Software policies support both Windows file-version checks and section/key/value checks for legacy INI files.
- Administrator management routes require a signed HttpOnly session; `/sync/*` uses the shared API key and hostname headers instead.
- LDAP service-account credentials and PKI private keys are encrypted at rest using a key derived from `SESSION_SECRET`; certificate status is exposed without returning private material.
- HTTPS activation starts the API with the stored PKI certificate when enabled, redirects proxied HTTP requests, and can emit HSTS after TLS is confirmed.
- The client API key is hashed for authentication and encrypted with `SESSION_SECRET` for intentional authenticated-administrator recovery; rotation or saving a chosen key returns clear text only through the explicit key-management flow.
- The Windows service remains non-interactive; a companion user-session process owns countdown notifications.

## Product

- Administrators can monitor enrolled clients, define enforcement policies, review sync history, manage LDAP administrators, upload organization PKI certificates, configure sync cadence, and manage the shared API key. Update Mode is configured per application.
- The uploaded Poste INI format is represented by rules such as `[Poste] Version=454` and `VersMedSyst=418`.

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

_Populate as you build — sharp edges, "always run X before Y" rules._

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
